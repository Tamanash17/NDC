════════════════════════════════════════════════════════════════════════════════
NDC API Transaction Log
════════════════════════════════════════════════════════════════════════════════

Session ID: session_mk7mbfg6_r8x187
Generated: 2026-01-10T01:21:00.220Z
Total API Calls: 6

────────────────────────────────────────────────────────────────────────────────
API Call Sequence:
────────────────────────────────────────────────────────────────────────────────

01. [✓] AirShopping (VIZ-SIN + SIN-VIZ, Economy)
    Time: 2026-01-10T01:20:10.279Z
    Duration: 5425ms
    Status: success

02. [✓] OfferPrice (VIZ-SIN + SIN-VIZ + SSRs)
    Time: 2026-01-10T01:20:31.288Z
    Duration: 0ms
    Status: success

03. [✓] ServiceList (VIZ-SIN + SIN-VIZ)
    Time: 2026-01-10T01:20:37.335Z
    Duration: 1326ms
    Status: success

04. [✓] OfferPrice (VIZ-SIN + SIN-VIZ + SSRs)
    Time: 2026-01-10T01:20:45.241Z
    Duration: 0ms
    Status: success

05. [✓] ServiceList (VIZ-SIN + SIN-VIZ)
    Time: 2026-01-10T01:20:48.932Z
    Duration: 1170ms
    Status: success

06. [✗] OfferPrice (VIZ-SIN + SIN-VIZ)
    Time: 2026-01-10T01:20:54.185Z
    Duration: 592ms
    Status: error

────────────────────────────────────────────────────────────────────────────────
File Naming Convention:
────────────────────────────────────────────────────────────────────────────────

Files are named: {sequence}_{operation}_{type}_{timestamp}.xml
  - sequence: 2-digit sequence number (01, 02, ...)
  - operation: NDC operation name (AirShopping, OfferPrice, etc.)
  - type: RQ (Request) or RS (Response)
  - timestamp: ISO timestamp

════════════════════════════════════════════════════════════════════════════════